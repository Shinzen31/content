import os, argparse, json, time
import numpy as np
import pandas as pd
import yaml

# Attempt Horovod import; fallback to single-process TF
try:
    import horovod.tensorflow.keras as hvd
    HOROVOD = True
except Exception:
    HOROVOD = False

from data_io import load_environments, load_groups, load_biomass, load_gsmm_features
from featurize import infer_candidates, build_candidate_index, composition_vector, pairwise_features, aggregate_gsmm_for_group, standardize_fit, standardize_apply
from models_tf import make_mlp

def make_features(cfg):
    env_df, env_cols = load_environments(os.path.join(cfg["data"]["dir"], cfg["data"]["environments_csv"]))
    groups_df = load_groups(os.path.join(cfg["data"]["dir"], cfg["data"]["groups_csv"]))
    biomass_df = load_biomass(os.path.join(cfg["data"]["dir"], cfg["data"]["biomass_csv"]))
    gsmm_df, gsmm_cols = load_gsmm_features(os.path.join(cfg["data"]["dir"], cfg["data"]["gsmm_features_csv"]))

    candidates = cfg["data"]["candidate_list"] or infer_candidates(groups_df)
    cand_index = build_candidate_index(candidates)

    df = pd.merge(groups_df, biomass_df, on=["env_id","k"], how="inner")
    df = pd.merge(df, env_df, on="env_id", how="left")

    rows = []
    for _, row in df.iterrows():
        env_id = row["env_id"]
        members = row["members"].split(";")
        env_feats = row[[c for c in env_df.columns if c != "env_id"]].to_numpy(dtype=np.float32)
        comp = composition_vector(members, cand_index) if cfg["features"]["one_hot_candidates"] else np.zeros(0, dtype=np.float32)
        pair = pairwise_features(members, cand_index) if cfg["features"]["include_pairwise"] else np.zeros(0, dtype=np.float32)
        gsmm_aggr = aggregate_gsmm_for_group(gsmm_df, gsmm_cols, env_id, members, cfg["project"].get("target_id"), cfg["features"]["gsmm_aggregations"])
        feats = np.concatenate([env_feats, comp, pair, gsmm_aggr]).astype(np.float32)
        rows.append({"features": feats, "label": row["biomass"]})
    feat_df = pd.DataFrame(rows)
    X = np.stack(feat_df["features"].values).astype(np.float32)
    y = feat_df["label"].astype(np.float32).values
    mean, std = (None, None)
    if cfg["features"]["standardize"]:
        mean, std = standardize_fit(X)
        X = standardize_apply(X, mean, std)
    return X, y

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", type=str, default="config.yaml")
    ap.add_argument("--dry_run", action="store_true")
    args = ap.parse_args()

    with open(args.config, "r") as f:
        cfg = yaml.safe_load(f)

    if HOROVOD:
        hvd.init()
        import tensorflow as tf
        gpus = tf.config.experimental.list_physical_devices('GPU')
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        if gpus:
            tf.config.set_visible_devices(gpus[hvd.local_rank()], 'GPU')

    X, y = make_features(cfg)
    if args.dry_run:
        print(f"[DRY RUN] X shape = {X.shape}, y shape = {y.shape}")
        return

    import tensorflow as tf
    strategy = None
    if HOROVOD:
        # Horovod optimizer & callbacks
        opt = tf.keras.optimizers.Adam(cfg["train"]["lr"])
        opt = hvd.DistributedOptimizer(opt)
    else:
        opt = tf.keras.optimizers.Adam(cfg["train"]["lr"])

    model = make_mlp(X.shape[1], tuple(cfg["model"]["hidden_sizes"]), cfg["model"]["dropout"], cfg["project"]["task_type"])
    model.compile(optimizer=opt, loss="mse", metrics=["mse"])

    callbacks = []
    if HOROVOD:
        callbacks += [
            hvd.callbacks.BroadcastGlobalVariablesCallback(0),
            hvd.callbacks.MetricAverageCallback(),
        ]
        if hvd.rank() == 0:
            outdir = os.path.join("runs", time.strftime("%Y%m%d-%H%M%S"))
            os.makedirs(outdir, exist_ok=True)
            ckpt_path = os.path.join(outdir, "best.h5")
            callbacks.append(tf.keras.callbacks.ModelCheckpoint(ckpt_path, save_best_only=True, monitor="val_mse", mode="min"))
    else:
        outdir = os.path.join("runs", time.strftime("%Y%m%d-%H%M%S"))
        os.makedirs(outdir, exist_ok=True)
        ckpt_path = os.path.join(outdir, "best.h5")
        callbacks.append(tf.keras.callbacks.ModelCheckpoint(ckpt_path, save_best_only=True, monitor="val_mse", mode="min"))

    # train/val/test split
    n = len(y)
    idx = np.arange(n)
    rng = np.random.RandomState(cfg["project"]["random_seed"])
    rng.shuffle(idx)
    n_test = int(n * cfg["train"]["test_split"])
    n_val = int(n * cfg["train"]["val_split"])
    test_idx = idx[:n_test]; val_idx = idx[n_test:n_test+n_val]; train_idx = idx[n_test+n_val:]

    Xtr, ytr = X[train_idx], y[train_idx]
    Xva, yva = X[val_idx], y[val_idx]
    Xte, yte = X[test_idx], y[test_idx]

    bs = cfg["train"]["batch_size"]
    epochs = cfg["train"]["epochs"]

    history = model.fit(
        Xtr, ytr,
        validation_data=(Xva, yva),
        epochs=epochs,
        batch_size=bs,
        callbacks=callbacks,
        verbose=1 if (not HOROVOD or hvd.rank()==0) else 0
    )

    if (not HOROVOD) or hvd.rank()==0:
        test_mse = model.evaluate(Xte, yte, verbose=0)[1]
        print(f"TEST MSE={test_mse:.4f}")

if __name__ == "__main__":
    main()
