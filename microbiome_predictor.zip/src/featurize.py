from typing import List, Dict, Tuple
import numpy as np
import pandas as pd

def infer_candidates(groups_df) -> List[str]:
    s = set()
    for m in groups_df["members"].values:
        for x in m.split(";"):
            s.add(x)
    return sorted(list(s))

def build_candidate_index(candidates: List[str]) -> Dict[str, int]:
    return {c:i for i,c in enumerate(candidates)}

def composition_vector(members: List[str], cand_index: Dict[str,int]) -> np.ndarray:
    v = np.zeros(len(cand_index), dtype=np.float32)
    for m in members:
        if m in cand_index:
            v[cand_index[m]] = 1.0
    return v

def pairwise_features(members: List[str], cand_index: Dict[str,int]) -> np.ndarray:
    # simple count of pairs present (upper triangle flattened); for stability we just count total pairs
    k = len(members)
    return np.array([k * (k-1) / 2.0], dtype=np.float32)

def aggregate_gsmm_for_group(gsmm_df: pd.DataFrame,
                             gsmm_cols: List[str],
                             env_id: str,
                             members: List[str],
                             target_id: str = None,
                             aggs: List[str] = ["mean","sum","max"]) -> np.ndarray:
    if gsmm_df is None or len(gsmm_cols) == 0:
        return np.zeros(0, dtype=np.float32)
    rows = gsmm_df[(gsmm_df["env_id"] == env_id) & (gsmm_df["strain_id"].isin(members))]
    mats = []
    if len(rows) == 0:
        mats.append(np.zeros(len(gsmm_cols), dtype=np.float32))
    else:
        X = rows[gsmm_cols].to_numpy(dtype=np.float32)
        for a in aggs:
            if a == "mean":
                mats.append(X.mean(axis=0))
            elif a == "sum":
                mats.append(X.sum(axis=0))
            elif a == "max":
                mats.append(X.max(axis=0))
    # Optionally include target GSMM features for the env
    if target_id is not None:
        trow = gsmm_df[(gsmm_df["env_id"] == env_id) & (gsmm_df["strain_id"] == target_id)]
        if len(trow) > 0:
            Xt = trow[gsmm_cols].to_numpy(dtype=np.float32)
            mats.append(Xt.squeeze(0))
        else:
            mats.append(np.zeros(len(gsmm_cols), dtype=np.float32))
    return np.concatenate(mats, axis=0).astype(np.float32)

def standardize_fit(X: np.ndarray):
    mean = X.mean(axis=0, keepdims=True)
    std = X.std(axis=0, keepdims=True) + 1e-8
    return mean, std

def standardize_apply(X: np.ndarray, mean, std):
    return (X - mean) / std
