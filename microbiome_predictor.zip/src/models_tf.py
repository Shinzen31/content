import tensorflow as tf

def make_mlp(in_dim, hidden_sizes=(512,256,128), dropout=0.1, task="regression"):
    inputs = tf.keras.Input(shape=(in_dim,), dtype=tf.float32)
    x = inputs
    for h in hidden_sizes:
        x = tf.keras.layers.Dense(h, activation="relu")(x)
        x = tf.keras.layers.Dropout(dropout)(x)
    outputs = tf.keras.layers.Dense(1)(x)
    model = tf.keras.Model(inputs=inputs, outputs=outputs)
    if task == "regression":
        model.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss="mse", metrics=["mse"])
    else:
        model.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss=tf.keras.losses.BinaryCrossentropy(from_logits=True), metrics=["accuracy"])
    return model
