import os, argparse, json
import numpy as np
import pandas as pd
import torch
from data_io import load_environments, load_gsmm_features
from featurize import build_candidate_index, composition_vector, pairwise_features, aggregate_gsmm_for_group, standardize_apply
from models_pytorch import MLP
import yaml

def load_meta(run_dir):
    with open(os.path.join(run_dir, "metrics.json"), "r") as f:
        return json.load(f)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", type=str, default="config.yaml")
    ap.add_argument("--run_dir", type=str, required=True)
    ap.add_argument("--env_id", type=str, required=True)
    ap.add_argument("--members", type=str, required=True, help="semicolon-separated list, e.g., S_01;S_22")
    args = ap.parse_args()

    with open(args.config, "r") as f:
        cfg = yaml.safe_load(f)

    env_df, _ = load_environments(os.path.join(cfg["data"]["dir"], cfg["data"]["environments_csv"]))
    gsmm_df, gsmm_cols = load_gsmm_features(os.path.join(cfg["data"]["dir"], cfg["data"]["gsmm_features_csv"]))

    # infer candidates from training data (requires groups.csv)
    groups_path = os.path.join(cfg["data"]["dir"], cfg["data"]["groups_csv"])
    import pandas as pd
    gdf = pd.read_csv(groups_path)
    candidates = sorted({m for row in gdf["members"].values for m in str(row).split(";") if m})
    cand_index = build_candidate_index(candidates)

    # build feature
    row = env_df[env_df["env_id"] == args.env_id].iloc[0]
    env_feats = row[[c for c in env_df.columns if c != "env_id"]].to_numpy(dtype=np.float32)
    members = [m.strip() for m in args.members.split(";") if m.strip()]
    comp = composition_vector(members, cand_index) if cfg["features"]["one_hot_candidates"] else np.zeros(0, dtype=np.float32)
    pair = pairwise_features(members, cand_index) if cfg["features"]["include_pairwise"] else np.zeros(0, dtype=np.float32)
    gsmm_aggr = aggregate_gsmm_for_group(gsmm_df, gsmm_cols, args.env_id, members, cfg["project"].get("target_id"), cfg["features"]["gsmm_aggregations"])
    x = np.concatenate([env_feats, comp, pair, gsmm_aggr])[None, :].astype(np.float32)

    meta = load_meta(args.run_dir)
    in_dim = meta["in_dim"]
    assert x.shape[1] == in_dim, f"feature dim mismatch: got {x.shape[1]}, expected {in_dim}"

    # load model
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = MLP(in_dim, tuple(cfg["model"]["hidden_sizes"]), cfg["model"]["dropout"], out_dim=1, task=cfg["project"]["task_type"]).to(device)
    state = torch.load(os.path.join(args.run_dir, "best.pt"), map_location=device)
    model.load_state_dict(state)
    model.eval()

    with torch.no_grad():
        x_t = torch.from_numpy(x).to(device)
        yhat = model(x_t).cpu().numpy().squeeze()
    print(json.dumps({"env_id": args.env_id, "members": args.members, "pred_biomass": float(yhat)}, indent=2))

if __name__ == "__main__":
    main()
