import os, json, argparse, time, math, random
import numpy as np
import pandas as pd
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import Dataset, DataLoader, DistributedSampler

from data_io import load_environments, load_groups, load_biomass, load_gsmm_features
from featurize import infer_candidates, build_candidate_index, composition_vector, pairwise_features, aggregate_gsmm_for_group, standardize_fit, standardize_apply
from models_pytorch import MLP
import yaml

class BioDataset(Dataset):
    def __init__(self, df, mean=None, std=None):
        self.X = np.stack(df["features"].values).astype(np.float32)
        self.y = df["label"].astype(np.float32).values
        if mean is not None:
            self.X = standardize_apply(self.X, mean, std)
        self.mean, self.std = mean, std
    def __len__(self):
        return len(self.y)
    def __getitem__(self, i):
        return torch.from_numpy(self.X[i]), torch.tensor(self.y[i])

def set_seed(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)

def make_features(cfg):
    env_df, env_cols = load_environments(os.path.join(cfg["data"]["dir"], cfg["data"]["environments_csv"]))
    groups_df = load_groups(os.path.join(cfg["data"]["dir"], cfg["data"]["groups_csv"]))
    biomass_df = load_biomass(os.path.join(cfg["data"]["dir"], cfg["data"]["biomass_csv"]))
    gsmm_df, gsmm_cols = load_gsmm_features(os.path.join(cfg["data"]["dir"], cfg["data"]["gsmm_features_csv"]))

    # candidate list
    candidates = cfg["data"]["candidate_list"] or infer_candidates(groups_df)
    cand_index = build_candidate_index(candidates)

    # join groups+biomass
    df = pd.merge(groups_df, biomass_df, on=["env_id","k"], how="inner")
    # join environment numeric
    df = pd.merge(df, env_df, on="env_id", how="left")

    rows = []
    for i, row in df.iterrows():
        env_id = row["env_id"]
        k = int(row["k"])
        members = row["members"].split(";")
        # env features
        env_feats = row[[c for c in env_df.columns if c != "env_id"]].to_numpy(dtype=np.float32)
        # composition features
        comp = composition_vector(members, cand_index) if cfg["features"]["one_hot_candidates"] else np.zeros(0, dtype=np.float32)
        pair = pairwise_features(members, cand_index) if cfg["features"]["include_pairwise"] else np.zeros(0, dtype=np.float32)
        # gsmm aggregated
        gsmm_aggr = aggregate_gsmm_for_group(gsmm_df, gsmm_cols, env_id, members,
                                             cfg["project"].get("target_id"), cfg["features"]["gsmm_aggregations"])
        feats = np.concatenate([env_feats, comp, pair, gsmm_aggr]).astype(np.float32)
        rows.append({"env_id": env_id, "k": k, "members": row["members"], "features": feats, "label": row["biomass"]})
    feat_df = pd.DataFrame(rows)
    # standardization
    X = np.stack(feat_df["features"].values).astype(np.float32)
    mean, std = (None, None)
    if cfg["features"]["standardize"]:
        mean, std = standardize_fit(X)
    return feat_df, mean, std

def split_indices(n, val_ratio, test_ratio, seed=123):
    idx = np.arange(n)
    rng = np.random.RandomState(seed)
    rng.shuffle(idx)
    n_test = int(n * test_ratio)
    n_val = int(n * val_ratio)
    test_idx = idx[:n_test]
    val_idx = idx[n_test:n_test+n_val]
    train_idx = idx[n_test+n_val:]
    return train_idx, val_idx, test_idx

def train_worker(rank, world_size, cfg, dry_run=False):
    device = torch.device(f"cuda:{rank}" if torch.cuda.is_available() else "cpu")
    if world_size > 1:
        dist.init_process_group(backend=cfg["ddp"]["backend"], rank=rank, world_size=world_size)

    set_seed(cfg["project"]["random_seed"] + rank)

    feat_df, mean, std = make_features(cfg)
    n = len(feat_df)
    tr, va, te = split_indices(n, cfg["train"]["val_split"], cfg["train"]["test_split"], seed=cfg["project"]["random_seed"])

    train_ds = BioDataset(feat_df.iloc[tr], mean if cfg["features"]["standardize"] else None, std if cfg["features"]["standardize"] else None)
    val_ds   = BioDataset(feat_df.iloc[va], mean if cfg["features"]["standardize"] else None, std if cfg["features"]["standardize"] else None)
    test_ds  = BioDataset(feat_df.iloc[te], mean if cfg["features"]["standardize"] else None, std if cfg["features"]["standardize"] else None)

    sampler = DistributedSampler(train_ds, num_replicas=world_size, rank=rank, shuffle=True) if world_size>1 else None
    train_loader = DataLoader(train_ds, batch_size=cfg["train"]["batch_size"], shuffle=(sampler is None), sampler=sampler, num_workers=cfg["train"]["num_workers"])
    val_loader   = DataLoader(val_ds, batch_size=cfg["train"]["batch_size"], shuffle=False, num_workers=cfg["train"]["num_workers"])
    test_loader  = DataLoader(test_ds, batch_size=cfg["train"]["batch_size"], shuffle=False, num_workers=cfg["train"]["num_workers"])

    in_dim = train_ds.X.shape[1]
    model = MLP(in_dim, tuple(cfg["model"]["hidden_sizes"]), cfg["model"]["dropout"], out_dim=1, task=cfg["project"]["task_type"])
    model = model.to(device)
    if world_size > 1:
        model = DDP(model, device_ids=[rank] if device.type=="cuda" else None)

    opt = torch.optim.AdamW(model.parameters(), lr=cfg["train"]["lr"], weight_decay=cfg["train"]["weight_decay"])
    best_val = float("inf")
    patience = cfg["train"]["patience"]
    bad = 0

    def step(loader, train=True):
        model.train() if train else model.eval()
        total_loss, total_n = 0.0, 0
        for X, y in loader:
            X = X.to(device); y = y.to(device)
            if train:
                opt.zero_grad()
            pred = model(X)
            loss = torch.nn.functional.mse_loss(pred, y)  # regression MSE
            if train:
                loss.backward()
                opt.step()
            total_loss += loss.item() * len(y)
            total_n += len(y)
        return total_loss / max(1,total_n)

    if dry_run:
        if rank==0:
            print(f"[DRY RUN] in_dim={in_dim}, n_train={len(train_ds)}, n_val={len(val_ds)}, n_test={len(test_ds)}")
        if world_size>1:
            dist.destroy_process_group()
        return

    outdir = os.path.join("runs", time.strftime("%Y%m%d-%H%M%S"))
    if rank==0:
        os.makedirs(outdir, exist_ok=True)

    for epoch in range(cfg["train"]["epochs"]):
        if world_size>1:
            sampler.set_epoch(epoch)
        tr_loss = step(train_loader, train=True)
        va_loss = step(val_loader, train=False)

        if rank==0:
            print(f"epoch {epoch}: train MSE={tr_loss:.4f}  val MSE={va_loss:.4f}")
            if va_loss < best_val - 1e-6:
                best_val = va_loss; bad = 0
                torch.save(model.module.state_dict() if isinstance(model, DDP) else model.state_dict(), os.path.join(outdir, "best.pt"))
                meta = {"epoch": epoch, "val_mse": va_loss, "train_mse": tr_loss, "in_dim": in_dim}
                with open(os.path.join(outdir, "metrics.json"), "w") as f:
                    json.dump(meta, f, indent=2)
            else:
                bad += 1
                if bad >= patience:
                    print("Early stopping.")
                    break

    # final test
    if rank==0:
        if os.path.exists(os.path.join(outdir, "best.pt")):
            (model.module if isinstance(model, DDP) else model).load_state_dict(torch.load(os.path.join(outdir, "best.pt"), map_location=device))
        test_mse = step(test_loader, train=False)
        print(f"TEST MSE={test_mse:.4f}")
    if world_size>1:
        dist.destroy_process_group()

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", type=str, default="config.yaml")
    ap.add_argument("--dry_run", action="store_true")
    ap.add_argument("--world_size", type=int, default=int(os.environ.get("WORLD_SIZE", "1")))
    ap.add_argument("--rank", type=int, default=int(os.environ.get("RANK", "0")))
    ap.add_argument("--local_rank", type=int, default=int(os.environ.get("LOCAL_RANK", "0")))
    return ap.parse_args()

if __name__ == "__main__":
    args = parse_args()
    with open(args.config, "r") as f:
        cfg = yaml.safe_load(f)
    train_worker(args.local_rank, args.world_size, cfg, dry_run=args.dry_run)
