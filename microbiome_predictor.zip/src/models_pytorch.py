import torch
import torch.nn as nn
import torch.nn.functional as F

class MLP(nn.Module):
    def __init__(self, in_dim, hidden_sizes=(512,256,128), dropout=0.1, out_dim=1, task="regression"):
        super().__init__()
        layers = []
        d = in_dim
        for h in hidden_sizes:
            layers += [nn.Linear(d, h), nn.ReLU(), nn.Dropout(dropout)]
            d = h
        self.backbone = nn.Sequential(*layers)
        self.head = nn.Linear(d, 1 if task=="regression" else 1)  # binary cls
        self.task = task

    def forward(self, x):
        z = self.backbone(x)
        y = self.head(z).squeeze(-1)
        return y
