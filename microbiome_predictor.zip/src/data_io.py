import os
import pandas as pd

def load_environments(path):
    df = pd.read_csv(path)
    assert "env_id" in df.columns, "environments.csv must have env_id"
    env_cols = [c for c in df.columns if c != "env_id"]
    return df, env_cols

def load_groups(path):
    df = pd.read_csv(path)
    required = {"env_id","k","members"}
    missing = required - set(df.columns)
    assert not missing, f"groups.csv missing columns: {missing}"
    # normalize members as sorted tuple of strings
    def norm(m):
        parts = [p.strip() for p in str(m).split(";") if p.strip()]
        return ";".join(sorted(parts))
    df["members"] = df["members"].apply(norm)
    return df

def load_biomass(path):
    df = pd.read_csv(path)
    required = {"env_id","k","biomass"}
    missing = required - set(df.columns)
    assert not missing, f"biomass.csv missing columns: {missing}"
    return df

def load_gsmm_features(path):
    if not os.path.exists(path):
        return None, []
    df = pd.read_csv(path)
    required = {"strain_id","env_id"}
    missing = required - set(df.columns)
    assert not missing, f"gsmm_features.csv missing columns: {missing}"
    feat_cols = [c for c in df.columns if c not in ("strain_id","env_id")]
    return df, feat_cols
