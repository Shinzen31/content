# Microbiome Partner Predictor

End-to-end baseline to predict target strain biomass from:
- Environment features (`environments.csv`)
- Best group compositions for sizes 1–4 (`groups.csv`)
- Biomass labels for target strain under each (env, group-size) (`biomass.csv`)
- Optional GSMM-derived features per strain and environment (`gsmm_features.csv`)
- Optional media/environment files (precompute features externally and provide as CSV)

It includes two scalable training baselines:
- **PyTorch DDP (GPU)** — `src/train_pytorch_ddp.py`
- **TensorFlow + Horovod (CPU)** — `src/train_tf_horovod.py`

> You can run with only CSVs. GSMM files are optional if you precompute features into `gsmm_features.csv`.

## File formats

### `environments.csv`
Required columns:
- `env_id` (string/int) unique environment identifier
- Any number of environment feature columns (numeric). Example: `pH`, `glucose`, `oxygen`, ...

### `groups.csv`
One row per (env_id, k) with the *best group* you found.
Required columns:
- `env_id`
- `k` (1,2,3,4)
- `members` — a semicolon-separated list of candidate IDs (e.g., `"S_03;S_11;S_22"`)
- Optional: `target_id` (if multiple targets; otherwise configure in config)

### `biomass.csv`
One row per (env_id, k) with label for the *target strain*.
Required columns:
- `env_id`
- `k`
- `biomass` — numeric

### `gsmm_features.csv` (optional but recommended)
Per (strain_id, env_id), numeric features summarizing GSMM outputs you precomputed (FBA, media, etc.).
Required columns:
- `strain_id`
- `env_id`
- any numeric columns, e.g., `fba_growth`, `aa_exporters`, `vitamin_req`, ...

> If you also have target-specific GSMM features, include rows with `strain_id == <target_id>`.

## Quickstart

1) Prepare a config (defaults are in `config.yaml`).

2) Train with PyTorch DDP (single node, 4 GPUs example):
```
torchrun --standalone --nproc_per_node=4 src/train_pytorch_ddp.py --config config.yaml
```

3) Train with TensorFlow + Horovod (CPU, 8 processes example):
```
horovodrun -np 8 -H localhost:8 python src/train_tf_horovod.py --config config.yaml
```

Both scripts accept `--dry_run` to verify data loading and feature shapes without training.

## Feature design (what the code does)

- Environment features: taken directly from `environments.csv`.
- Group composition features:
  - 39-length binary vector for candidate presence.
  - Optional pairwise counts up to size k (disabled by default — enable in config).
- GSMM features:
  - For each member \(and the target\), we aggregate per-group by mean/max/sum (`agg: ["mean","sum","max"]` selectable).
  - If `gsmm_features.csv` missing, the model uses only environment + composition features.

## Targets
- Default is regression on `biomass` (MSE/RMSE, R²). You can switch to classification with a threshold in config.

## Outputs
- Checkpoints in `runs/<timestamp>` with metrics JSON.
- `inference.py` shows how to run prediction on new (env_id, k, members) tuples.

## Notes
- The project avoids non-standard dependencies so it can run in vanilla environments. Install only Torch, TF, Horovod as needed.
- If you want to integrate COBRApy for GSMM parsing, precompute features and write to `gsmm_features.csv` using your pipeline.
